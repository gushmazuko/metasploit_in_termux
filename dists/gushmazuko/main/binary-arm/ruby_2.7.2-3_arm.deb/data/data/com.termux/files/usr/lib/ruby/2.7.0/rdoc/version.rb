module RDoc

  ##
  # RDoc version you are using

  VERSION = '6.2.1'

end
