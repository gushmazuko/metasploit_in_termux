module Forwardable
  # Version of +forwardable.rb+
  VERSION = "1.3.1"
  FORWARDABLE_VERSION = VERSION
end
